"""
Application Configuration
=========================
Asosiy application konfiguratsiyasi.

Author: TergooAI Team
Date: 2024
"""

import os
from pathlib import Path
from typing import Optional
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    """Application settings."""
    
    # Application
    APP_NAME: str = "TergooAI"
    APP_VERSION: str = "1.0.0"
    ENVIRONMENT: str = os.getenv("ENVIRONMENT", "development")
    DEBUG: bool = os.getenv("DEBUG", "true").lower() == "true"
    
    # API
    API_HOST: str = os.getenv("API_HOST", "0.0.0.0")
    API_PORT: int = int(os.getenv("API_PORT", "8000"))
    API_RELOAD: bool = os.getenv("API_RELOAD", "true").lower() == "true"
    
    # Paths
    DATA_DIR: Path = Path(os.getenv("DATA_DIR", "data"))
    JK_DIR: Path = Path(os.getenv("JK_DIR", "data/JK"))
    JPK_DIR: Path = Path(os.getenv("JPK_DIR", "data/JPK"))
    KRIM_DIR: Path = Path(os.getenv("KRIM_DIR", "data/kriminalistika"))
    INDEX_DIR: Path = Path(os.getenv("INDEX_DIR", "data/faiss_index"))
    CACHE_DIR: Path = Path(os.getenv("CACHE_DIR", "data/cache"))
    LOGS_DIR: Path = Path(os.getenv("LOGS_DIR", "logs"))
    
    # ML Settings
    EMBEDDING_MODEL: str = os.getenv(
        "EMBEDDING_MODEL",
        "paraphrase-multilingual-mpnet-base-v2"
    )
    EMBEDDING_DIMENSION: int = int(os.getenv("EMBEDDING_DIMENSION", "768"))
    SEARCH_TOP_K: int = int(os.getenv("SEARCH_TOP_K", "5"))
    SIMILARITY_THRESHOLD: float = float(os.getenv("SIMILARITY_THRESHOLD", "0.6"))
    
    # Cache Settings
    ENABLE_CACHE: bool = os.getenv("ENABLE_CACHE", "true").lower() == "true"
    
    # Logging
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "INFO")
    
    # CORS
    CORS_ORIGINS: list = [
        "http://localhost",
        "http://localhost:3000",
        "http://localhost:8000",
        "*"  # Allow all in development
    ]
    
    class Config:
        case_sensitive = True
        env_file = ".env"


# Create settings instance
settings = Settings()


def get_settings() -> Settings:
    """Get settings instance."""
    return settings


# ============================================================================
# HELPER FUNCTIONS
# ============================================================================

def ensure_directories():
    """Ensure all required directories exist."""
    directories = [
        settings.DATA_DIR,
        settings.JK_DIR,
        settings.JPK_DIR,
        settings.KRIM_DIR,
        settings.INDEX_DIR,
        settings.CACHE_DIR,
        settings.LOGS_DIR
    ]
    
    for directory in directories:
        Path(directory).mkdir(parents=True, exist_ok=True)


if __name__ == "__main__":
    # Test configuration
    print("=" * 60)
    print("CONFIGURATION TEST")
    print("=" * 60)
    
    s = get_settings()
    
    print(f"\nApp Name: {s.APP_NAME}")
    print(f"Version: {s.APP_VERSION}")
    print(f"Environment: {s.ENVIRONMENT}")
    print(f"Debug: {s.DEBUG}")
    
    print(f"\nAPI Host: {s.API_HOST}")
    print(f"API Port: {s.API_PORT}")
    
    print(f"\nData Directory: {s.DATA_DIR}")
    print(f"JK Directory: {s.JK_DIR}")
    print(f"JPK Directory: {s.JPK_DIR}")
    print(f"Kriminalistika Directory: {s.KRIM_DIR}")
    
    print(f"\nEmbedding Model: {s.EMBEDDING_MODEL}")
    print(f"Embedding Dimension: {s.EMBEDDING_DIMENSION}")
    
    print("\nEnsuring directories...")
    ensure_directories()
    print("✅ All directories created")
