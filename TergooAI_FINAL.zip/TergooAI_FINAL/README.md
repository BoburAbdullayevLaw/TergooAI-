# 🤖 TergooAI - Semantic Search System

ML-powered semantic qidiruv tizimi (JK, JPK, Kriminalistika).

## 🚀 Quick Start

### 1. Install Dependencies
```bash
pip install -r requirements.txt
```

### 2. Prepare Data
```
data/
├── JK/              # Jinoyat Kodeksi
├── JPK/             # Jinoyat-Protsessual Kodeks
└── kriminalistika/  # Kriminalistika
```

### 3. Run
```bash
python run.py
```

### 4. Test API
```bash
curl -X POST "http://localhost:8000/search" \
  -H "Content-Type: application/json" \
  -d '{"query": "JK 97-2(a) nima?", "top_k": 5}'
```

## ✨ Features

- ✅ Semantic search (multilingual)
- ✅ 3 data sources: JK, JPK, Kriminalistika
- ✅ FAISS vector database
- ✅ FastAPI REST API
- ✅ Emoji preserved (✅ emojilar saqlanadi!)

## 📊 API Endpoints

- `POST /search` - Semantic search
- `GET /document/{id}` - Get document by ID
- `GET /stats` - System statistics
- `GET /health` - Health check

## 🎯 Architecture

```
TergooAI/
├── data/           # Data directories
├── ML/             # ML system
├── main.py         # FastAPI app
├── database.py     # Data loader
└── requirements.txt
```

## 📝 Example

```python
import requests

response = requests.post(
    "http://localhost:8000/search",
    json={"query": "Qasddan odam o'ldirish", "top_k": 3}
)
print(response.json())
```

## ✅ Data Format

Documents kan have:
- `id`: Unique ID
- `asosiy_matn`: Main text
- `emoji_sarlavha`: Title with emoji (preserved!)
- `tushuntirish`: Explanation
- Other custom fields

## 🔧 Configuration

Edit `ML/utils/config.py` for custom settings.

---

**Author:** TergooAI Team  
**Version:** 1.0.0
