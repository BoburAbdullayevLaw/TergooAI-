"""
Performance Benchmark Module
============================
Performance testing.

Author: TergooAI Team
"""

import time
from typing import Dict, Any, List
import numpy as np
import logging

logger = logging.getLogger(__name__)


class PerformanceBenchmark:
    """
    Performance benchmark va profiling.
    """
    
    def benchmark_search_speed(
        self,
        search_engine,
        num_queries: int = 100,
        top_k: int = 5
    ) -> Dict[str, float]:
        """
        Qidiruv tezligini test qilish.
        
        Args:
            search_engine: Search engine instance
            num_queries: Number of test queries
            top_k: Number of results per query
        
        Returns:
            dict: Benchmark results
        """
        logger.info(f"Running search speed benchmark ({num_queries} queries)...")
        
        # Generate test queries
        test_queries = [f"test query {i}" for i in range(num_queries)]
        
        times = []
        
        for query in test_queries:
            start_time = time.time()
            try:
                search_engine.search(query, top_k=top_k)
            except Exception as e:
                logger.error(f"Search error: {e}")
            elapsed = time.time() - start_time
            times.append(elapsed)
        
        times = np.array(times)
        
        results = {
            'num_queries': num_queries,
            'total_time': float(times.sum()),
            'avg_time': float(times.mean()),
            'min_time': float(times.min()),
            'max_time': float(times.max()),
            'std_time': float(times.std()),
            'qps': num_queries / times.sum(),  # Queries per second
            'latency_p50': float(np.percentile(times, 50)),
            'latency_p95': float(np.percentile(times, 95)),
            'latency_p99': float(np.percentile(times, 99))
        }
        
        logger.info(f"✅ Benchmark complete:")
        logger.info(f"   Avg time: {results['avg_time']*1000:.2f}ms")
        logger.info(f"   QPS: {results['qps']:.2f}")
        logger.info(f"   P95 latency: {results['latency_p95']*1000:.2f}ms")
        
        return results
    
    def benchmark_embedding_generation(
        self,
        generator,
        num_documents: int = 100
    ) -> Dict[str, float]:
        """
        Embedding generation tezligi.
        
        Args:
            generator: Embedding generator instance
            num_documents: Number of test documents
        
        Returns:
            dict: Benchmark results
        """
        logger.info(f"Running embedding benchmark ({num_documents} documents)...")
        
        # Generate test documents
        test_docs = [
            {
                'id': f'test-{i}',
                'asosiy_matn': f'Test document {i} with some content for testing'
            }
            for i in range(num_documents)
        ]
        
        start_time = time.time()
        embeddings = generator.generate_batch_embeddings(test_docs, show_progress=False)
        elapsed = time.time() - start_time
        
        results = {
            'num_documents': num_documents,
            'total_time': elapsed,
            'avg_time': elapsed / num_documents,
            'docs_per_second': num_documents / elapsed
        }
        
        logger.info(f"✅ Embedding benchmark complete:")
        logger.info(f"   Avg time: {results['avg_time']*1000:.2f}ms")
        logger.info(f"   Docs/sec: {results['docs_per_second']:.2f}")
        
        return results
    
    def benchmark_index_search(
        self,
        vector_db,
        num_searches: int = 1000,
        dimension: int = 768,
        k: int = 5
    ) -> Dict[str, float]:
        """
        FAISS index qidiruv tezligi.
        
        Args:
            vector_db: FAISS database instance
            num_searches: Number of search operations
            dimension: Embedding dimension
            k: Number of results
        
        Returns:
            dict: Benchmark results
        """
        logger.info(f"Running index search benchmark ({num_searches} searches)...")
        
        # Generate random query vectors
        query_vectors = np.random.randn(num_searches, dimension).astype(np.float32)
        
        times = []
        
        for query_vector in query_vectors:
            start_time = time.time()
            try:
                vector_db.search(query_vector, k=k)
            except Exception:
                pass
            elapsed = time.time() - start_time
            times.append(elapsed)
        
        times = np.array(times)
        
        results = {
            'num_searches': num_searches,
            'total_time': float(times.sum()),
            'avg_time': float(times.mean()),
            'searches_per_second': num_searches / times.sum(),
            'latency_p50': float(np.percentile(times, 50)),
            'latency_p95': float(np.percentile(times, 95))
        }
        
        logger.info(f"✅ Index benchmark complete:")
        logger.info(f"   Avg time: {results['avg_time']*1000:.2f}ms")
        logger.info(f"   Searches/sec: {results['searches_per_second']:.2f}")
        
        return results


# Test
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    print("\n📊 Performance Benchmark Module")
    print("=" * 60)
    print("Available benchmarks:")
    print("1. Search speed benchmark")
    print("2. Embedding generation benchmark")
    print("3. Index search benchmark")
