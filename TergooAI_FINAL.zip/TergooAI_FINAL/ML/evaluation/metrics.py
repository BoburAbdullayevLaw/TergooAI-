"""
Retrieval Metrics Module
========================
Baholash metrikalari.

Author: TergooAI Team
"""

import numpy as np
from typing import List, Set


class RetrievalMetrics:
    """
    Retrieval quality metrikalari.
    """
    
    @staticmethod
    def precision_at_k(retrieved: List[str], relevant: Set[str], k: int) -> float:
        """
        Precision@K: K ta natijada nechta to'g'ri.
        
        Args:
            retrieved: Retrieved document IDs
            relevant: Relevant document IDs
            k: K value
        
        Returns:
            float: Precision score
        """
        retrieved_k = set(retrieved[:k])
        true_positives = len(retrieved_k & relevant)
        return true_positives / k if k > 0 else 0.0
    
    @staticmethod
    def recall_at_k(retrieved: List[str], relevant: Set[str], k: int) -> float:
        """
        Recall@K: Barcha to'g'rilardan nechta topildi.
        
        Args:
            retrieved: Retrieved document IDs
            relevant: Relevant document IDs
            k: K value
        
        Returns:
            float: Recall score
        """
        retrieved_k = set(retrieved[:k])
        true_positives = len(retrieved_k & relevant)
        return true_positives / len(relevant) if relevant else 0.0
    
    @staticmethod
    def mrr(retrieved_lists: List[List[str]], relevant_lists: List[Set[str]]) -> float:
        """
        Mean Reciprocal Rank: Birinchi to'g'ri javobning o'rni.
        
        Args:
            retrieved_lists: List of retrieved lists
            relevant_lists: List of relevant sets
        
        Returns:
            float: MRR score
        """
        reciprocal_ranks = []
        
        for retrieved, relevant in zip(retrieved_lists, relevant_lists):
            for i, item in enumerate(retrieved, 1):
                if item in relevant:
                    reciprocal_ranks.append(1.0 / i)
                    break
            else:
                reciprocal_ranks.append(0.0)
        
        return np.mean(reciprocal_ranks) if reciprocal_ranks else 0.0
    
    @staticmethod
    def ndcg_at_k(retrieved: List[str], relevant: Set[str], k: int) -> float:
        """
        Normalized Discounted Cumulative Gain@K.
        
        Args:
            retrieved: Retrieved document IDs
            relevant: Relevant document IDs
            k: K value
        
        Returns:
            float: NDCG score
        """
        dcg = 0.0
        for i, item in enumerate(retrieved[:k], 1):
            if item in relevant:
                dcg += 1.0 / np.log2(i + 1)
        
        # Ideal DCG
        idcg = sum(1.0 / np.log2(i + 1) for i in range(1, min(len(relevant), k) + 1))
        
        return dcg / idcg if idcg > 0 else 0.0
    
    @staticmethod
    def f1_score(precision: float, recall: float) -> float:
        """
        F1 Score.
        
        Args:
            precision: Precision value
            recall: Recall value
        
        Returns:
            float: F1 score
        """
        if precision + recall == 0:
            return 0.0
        return 2 * (precision * recall) / (precision + recall)


# Test
if __name__ == "__main__":
    metrics = RetrievalMetrics()
    
    retrieved = ["doc1", "doc2", "doc3", "doc4", "doc5"]
    relevant = {"doc1", "doc3", "doc5"}
    
    p_at_3 = metrics.precision_at_k(retrieved, relevant, k=3)
    r_at_3 = metrics.recall_at_k(retrieved, relevant, k=3)
    f1 = metrics.f1_score(p_at_3, r_at_3)
    
    print(f"Precision@3: {p_at_3:.2f}")
    print(f"Recall@3: {r_at_3:.2f}")
    print(f"F1 Score: {f1:.2f}")
