"""
Test Suite Module
=================
Test to'plamlari.

Author: TergooAI Team
"""

from typing import List, Dict, Any
import logging

logger = logging.getLogger(__name__)


class TestSuite:
    """
    Test to'plamlari va smoke tests.
    """
    
    SMOKE_TESTS = [
        {
            "query": "JK 97-2(a) nima?",
            "expected_in_top_5": ["JK-097"],
            "description": "JK 97 modda qidiruvi"
        },
        {
            "query": "Ikki odamni o'ldirish",
            "expected_in_top_5": ["JK-097"],
            "description": "Ikki odam o'ldirish"
        },
        {
            "query": "Og'irlashtiruvchi holatlar",
            "expected_in_top_5": ["JK-097"],
            "description": "Og'irlashtiruvchi holatlar"
        },
        {
            "query": "Tergovchi vakolatlari",
            "expected_in_top_5": ["JPK"],
            "description": "JPK qidiruvi"
        }
    ]
    
    def run_smoke_tests(self, search_engine, top_k: int = 5) -> Dict[str, Any]:
        """
        Run smoke tests.
        
        Args:
            search_engine: Search engine instance
            top_k: Number of results to check
        
        Returns:
            dict: Test results
        """
        logger.info("Running smoke tests...")
        
        results = {
            'total': len(self.SMOKE_TESTS),
            'passed': 0,
            'failed': 0,
            'details': []
        }
        
        for test in self.SMOKE_TESTS:
            query = test['query']
            expected = test['expected_in_top_5']
            description = test['description']
            
            try:
                search_results = search_engine.search(query, top_k=top_k)
                retrieved_ids = [r.sharx_id for r in search_results]
                
                # Check if any expected ID is in results
                found = any(
                    any(exp in rid for exp in expected)
                    for rid in retrieved_ids
                )
                
                if found:
                    results['passed'] += 1
                    status = 'PASS'
                else:
                    results['failed'] += 1
                    status = 'FAIL'
                
                results['details'].append({
                    'query': query,
                    'description': description,
                    'status': status,
                    'retrieved': retrieved_ids[:3]
                })
                
                logger.info(f"  [{status}] {description}")
                
            except Exception as e:
                results['failed'] += 1
                results['details'].append({
                    'query': query,
                    'description': description,
                    'status': 'ERROR',
                    'error': str(e)
                })
                logger.error(f"  [ERROR] {description}: {e}")
        
        logger.info(f"Smoke tests: {results['passed']}/{results['total']} passed")
        
        return results
    
    def run_custom_tests(
        self,
        search_engine,
        test_cases: List[Dict[str, Any]]
    ) -> Dict[str, Any]:
        """
        Run custom test cases.
        
        Args:
            search_engine: Search engine instance
            test_cases: List of test cases
        
        Returns:
            dict: Test results
        """
        results = {
            'total': len(test_cases),
            'passed': 0,
            'failed': 0,
            'details': []
        }
        
        for test in test_cases:
            query = test['query']
            expected = test.get('expected', [])
            
            try:
                search_results = search_engine.search(query, top_k=5)
                retrieved_ids = [r.sharx_id for r in search_results]
                
                found = any(exp in str(retrieved_ids) for exp in expected)
                
                if found:
                    results['passed'] += 1
                    status = 'PASS'
                else:
                    results['failed'] += 1
                    status = 'FAIL'
                
                results['details'].append({
                    'query': query,
                    'status': status,
                    'retrieved': retrieved_ids[:3]
                })
                
            except Exception as e:
                results['failed'] += 1
                results['details'].append({
                    'query': query,
                    'status': 'ERROR',
                    'error': str(e)
                })
        
        return results


# Test
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    suite = TestSuite()
    
    print("\n📋 Available Smoke Tests:")
    for i, test in enumerate(suite.SMOKE_TESTS, 1):
        print(f"{i}. {test['description']}: '{test['query']}'")
