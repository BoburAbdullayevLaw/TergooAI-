"""
Tokenizer Module
================
Simple tokenization.

Author: TergooAI Team
"""

import re
from typing import List


class SimpleTokenizer:
    """Simple tokenizer."""
    
    def tokenize(self, text: str, level: str = 'word') -> List[str]:
        """
        Tokenize text.
        
        Args:
            text: Input text
            level: 'word' or 'sentence'
        
        Returns:
            List[str]: Tokens
        """
        if level == 'word':
            return self._word_tokenize(text)
        elif level == 'sentence':
            return self._sentence_tokenize(text)
        else:
            raise ValueError(f"Unknown level: {level}")
    
    def _word_tokenize(self, text: str) -> List[str]:
        """Word tokenization."""
        words = re.findall(r'\b\w+\b', text)
        return words
    
    def _sentence_tokenize(self, text: str) -> List[str]:
        """Sentence tokenization."""
        sentences = re.split(r'[.!?]+', text)
        sentences = [s.strip() for s in sentences if s.strip()]
        return sentences


# Test
if __name__ == "__main__":
    tokenizer = SimpleTokenizer()
    
    text = "JK 97-2(a) nima? Bu modda ikki odamni o'ldirish haqida."
    
    words = tokenizer.tokenize(text, level='word')
    sentences = tokenizer.tokenize(text, level='sentence')
    
    print(f"Words: {words}")
    print(f"Sentences: {sentences}")
