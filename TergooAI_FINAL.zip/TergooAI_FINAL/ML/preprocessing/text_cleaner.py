"""
Text Cleaner - MINIMAL VERSION
===============================
Faqat zarur tozalash.

✅ EMOJI SAQLANADI!
✅ Maxsus belgilar SAQLANADI!

Author: TergooAI Team
Date: 2024
"""

import re
import unicodedata
from typing import Optional


class TextCleaner:
    """
    Minimal matn tozalash.
    
    Nima qiladi:
    - ✅ Unicode normalizatsiya (emoji saqlanadi)
    - ✅ HTML teglarini olib tashlash
    - ✅ Ortiqcha bo'shliqlarni tozalash
    
    Nima QILMAYDI:
    - ❌ Emoji olib tashlamaydi
    - ❌ Maxsus belgilarni olib tashlamaydi
    - ❌ Punctuation olib tashlamaydi
    """
    
    def __init__(self):
        """Initialize Text Cleaner."""
        pass
    
    
    def clean_text(self, text: str) -> str:
        """
        MINIMAL matn tozalash.
        
        Args:
            text: Input text
        
        Returns:
            str: Cleaned text (emoji va maxsus belgilar SAQLANADI!)
        
        Example:
            >>> cleaner = TextCleaner()
            >>> text = "  ⚖️ JK 97-2(a) 👥 ikki odam  "
            >>> clean = cleaner.clean_text(text)
            >>> print(clean)
            "⚖️ JK 97-2(a) 👥 ikki odam"
        """
        if not text or not isinstance(text, str):
            return ""
        
        # 1. Unicode normalizatsiya (NFC)
        # Emoji SAQLANADI!
        text = unicodedata.normalize('NFC', text)
        
        # 2. HTML teglarini olib tashlash (agar bo'lsa)
        text = self._remove_html_tags(text)
        
        # 3. Ortiqcha bo'shliqlarni tozalash
        text = self._clean_whitespace(text)
        
        # 4. Boshi va oxirini trim
        text = text.strip()
        
        return text
    
    
    def _remove_html_tags(self, text: str) -> str:
        """
        HTML teglarini olib tashlash.
        
        Args:
            text: Input text
        
        Returns:
            str: Text without HTML tags
        """
        # Remove HTML tags: <tag>, </tag>, <tag attr="value">
        text = re.sub(r'<[^>]+>', '', text)
        
        # Remove HTML entities: &nbsp;, &amp;, etc.
        text = re.sub(r'&\w+;', ' ', text)
        
        return text
    
    
    def _clean_whitespace(self, text: str) -> str:
        """
        Ortiqcha bo'shliqlarni tozalash.
        
        Args:
            text: Input text
        
        Returns:
            str: Text with normalized whitespace
        """
        # Multiple spaces/tabs/newlines -> single space
        text = re.sub(r'\s+', ' ', text)
        
        return text
    
    
    def clean_batch(self, texts: list) -> list:
        """
        Ko'p matnlarni birga tozalash.
        
        Args:
            texts: List of texts
        
        Returns:
            list: List of cleaned texts
        """
        return [self.clean_text(text) for text in texts]


# ============================================================================
# TEST
# ============================================================================

if __name__ == "__main__":
    cleaner = TextCleaner()
    
    print("=" * 60)
    print("TEXT CLEANER TEST")
    print("=" * 60)
    
    # Test 1: Emoji preservation
    print("\n1. EMOJI PRESERVATION TEST:")
    text1 = "  ⚖️ JK 97-2(a) 👥 ikki odam  "
    clean1 = cleaner.clean_text(text1)
    print(f"   Input:  '{text1}'")
    print(f"   Output: '{clean1}'")
    print(f"   Emoji preserved: {'✅' if '⚖️' in clean1 and '👥' in clean1 else '❌'}")
    
    # Test 2: HTML tags removal
    print("\n2. HTML TAGS REMOVAL TEST:")
    text2 = "<p>JK 97</p> <b>sharh</b>"
    clean2 = cleaner.clean_text(text2)
    print(f"   Input:  '{text2}'")
    print(f"   Output: '{clean2}'")
    print(f"   HTML removed: {'✅' if '<' not in clean2 else '❌'}")
    
    # Test 3: Whitespace cleaning
    print("\n3. WHITESPACE CLEANING TEST:")
    text3 = "JK    97\n\n\tsharh"
    clean3 = cleaner.clean_text(text3)
    print(f"   Input:  '{text3}'")
    print(f"   Output: '{clean3}'")
    print(f"   Whitespace normalized: {'✅' if '  ' not in clean3 else '❌'}")
    
    # Test 4: Complex text with emoji
    print("\n4. COMPLEX TEXT TEST:")
    text4 = """
    <h1>⚖️ JK 97-2(a)</h1>
    <p>👥 Ikki   yoki  undan   ortiq</p>
    🔴 Og'irlashtiruvchi holatlar
    """
    clean4 = cleaner.clean_text(text4)
    print(f"   Input:  '{text4[:50]}...'")
    print(f"   Output: '{clean4}'")
    print(f"   All preserved: {'✅' if all(e in clean4 for e in ['⚖️', '👥', '🔴']) else '❌'}")
    
    print("\n" + "=" * 60)
    print("✅ ALL TESTS COMPLETE")
    print("=" * 60)
