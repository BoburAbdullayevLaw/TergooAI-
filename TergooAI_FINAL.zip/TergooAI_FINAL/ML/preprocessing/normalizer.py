"""
Text Normalizer Module
======================
Matnni normallash (MINIMAL).

Author: TergooAI Team
"""

import re


class TextNormalizer:
    """Minimal text normalization."""
    
    def normalize(self, text: str, lowercase: bool = True) -> str:
        """
        Normalize text.
        
        Args:
            text: Input text
            lowercase: Convert to lowercase
        
        Returns:
            str: Normalized text
        """
        if not text:
            return ""
        
        if lowercase:
            text = text.lower()
        
        # Normalize whitespace
        text = re.sub(r'\s+', ' ', text)
        
        return text.strip()


# Test
if __name__ == "__main__":
    normalizer = TextNormalizer()
    
    text = "  JK  97-2(a)   NIMA?  "
    normalized = normalizer.normalize(text)
    
    print(f"Original: '{text}'")
    print(f"Normalized: '{normalized}'")
