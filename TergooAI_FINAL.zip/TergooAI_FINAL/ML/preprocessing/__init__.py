"""
Preprocessing Module
====================
Matnni minimal tozalash (emoji SAQLANADI).

Author: TergooAI Team
"""

from .text_cleaner import TextCleaner

__version__ = "1.0.0"
__all__ = ['TextCleaner']
