"""
Embedding Cache Module
======================
Embeddinglarni cache qilish (memory va disk).

Author: TergooAI Team
Date: 2024
"""

import numpy as np
import pickle
from typing import Dict, Optional
from pathlib import Path
import logging
from collections import OrderedDict
import hashlib

logger = logging.getLogger(__name__)


class LRUCache:
    """
    Simple LRU (Least Recently Used) Cache.
    Thread-safe implementation.
    """
    
    def __init__(self, capacity: int = 1000):
        """
        Initialize LRU Cache.
        
        Args:
            capacity: Maximum number of items
        """
        self.capacity = capacity
        self.cache = OrderedDict()
        self.hits = 0
        self.misses = 0
    
    def get(self, key: str) -> Optional[np.ndarray]:
        """Get item from cache."""
        if key not in self.cache:
            self.misses += 1
            return None
        
        # Move to end (most recently used)
        self.cache.move_to_end(key)
        self.hits += 1
        return self.cache[key]
    
    def put(self, key: str, value: np.ndarray):
        """Put item to cache."""
        if key in self.cache:
            self.cache.move_to_end(key)
        else:
            self.cache[key] = value
            if len(self.cache) > self.capacity:
                # Remove oldest
                self.cache.popitem(last=False)
    
    def clear(self):
        """Clear cache."""
        self.cache.clear()
        self.hits = 0
        self.misses = 0
    
    def size(self) -> int:
        """Get cache size."""
        return len(self.cache)
    
    def hit_rate(self) -> float:
        """Calculate hit rate."""
        total = self.hits + self.misses
        return self.hits / total if total > 0 else 0.0


class DiskCache:
    """
    Disk-based cache for persistence.
    """
    
    def __init__(self, cache_dir: Path = None):
        """
        Initialize Disk Cache.
        
        Args:
            cache_dir: Cache directory
        """
        self.cache_dir = cache_dir or Path("data/cache/embeddings")
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        logger.info(f"DiskCache initialized at {self.cache_dir}")
    
    def _get_filename(self, key: str) -> Path:
        """Generate filename from key."""
        key_hash = hashlib.md5(key.encode()).hexdigest()
        return self.cache_dir / f"{key_hash}.npy"
    
    def get(self, key: str) -> Optional[np.ndarray]:
        """Get embedding from disk."""
        filename = self._get_filename(key)
        if not filename.exists():
            return None
        
        try:
            return np.load(filename)
        except Exception as e:
            logger.error(f"Error loading from disk: {e}")
            return None
    
    def put(self, key: str, embedding: np.ndarray):
        """Save embedding to disk."""
        filename = self._get_filename(key)
        try:
            np.save(filename, embedding)
        except Exception as e:
            logger.error(f"Error saving to disk: {e}")
    
    def delete(self, key: str):
        """Delete from disk."""
        filename = self._get_filename(key)
        if filename.exists():
            filename.unlink()
    
    def clear(self):
        """Clear all cache files."""
        for filename in self.cache_dir.glob("*.npy"):
            filename.unlink()


class EmbeddingCache:
    """
    Multi-level caching system.
    
    Levels:
    1. Memory (LRU) - Fastest
    2. Disk - Persistent
    """
    
    def __init__(
        self,
        use_memory: bool = True,
        use_disk: bool = True,
        memory_capacity: int = 1000,
        disk_cache_dir: Path = None
    ):
        """
        Initialize Multi-level Cache.
        
        Args:
            use_memory: Enable memory cache
            use_disk: Enable disk cache
            memory_capacity: Memory cache capacity
            disk_cache_dir: Disk cache directory
        """
        self.memory_cache = LRUCache(capacity=memory_capacity) if use_memory else None
        self.disk_cache = DiskCache(cache_dir=disk_cache_dir) if use_disk else None
        
        self.stats = {
            'memory_hits': 0,
            'disk_hits': 0,
            'misses': 0,
            'total_requests': 0
        }
        
        logger.info(f"EmbeddingCache initialized: memory={use_memory}, disk={use_disk}")
    
    def get(self, key: str) -> Optional[np.ndarray]:
        """
        Get embedding from cache (multi-level).
        
        Args:
            key: Cache key
        
        Returns:
            np.ndarray or None: Cached embedding
        """
        self.stats['total_requests'] += 1
        
        # L1: Memory cache
        if self.memory_cache:
            embedding = self.memory_cache.get(key)
            if embedding is not None:
                self.stats['memory_hits'] += 1
                return embedding
        
        # L2: Disk cache
        if self.disk_cache:
            embedding = self.disk_cache.get(key)
            if embedding is not None:
                self.stats['disk_hits'] += 1
                # Populate L1
                if self.memory_cache:
                    self.memory_cache.put(key, embedding)
                return embedding
        
        # Miss
        self.stats['misses'] += 1
        return None
    
    def put(self, key: str, embedding: np.ndarray):
        """Put embedding to cache (all levels)."""
        if self.memory_cache:
            self.memory_cache.put(key, embedding)
        if self.disk_cache:
            self.disk_cache.put(key, embedding)
    
    def delete(self, key: str):
        """Delete from all cache levels."""
        if self.memory_cache:
            self.memory_cache.cache.pop(key, None)
        if self.disk_cache:
            self.disk_cache.delete(key)
    
    def clear(self):
        """Clear all cache levels."""
        if self.memory_cache:
            self.memory_cache.clear()
        if self.disk_cache:
            self.disk_cache.clear()
        self.stats = {'memory_hits': 0, 'disk_hits': 0, 'misses': 0, 'total_requests': 0}
        logger.info("All caches cleared")
    
    def get_stats(self) -> Dict:
        """Get cache statistics."""
        total = self.stats['total_requests']
        total_hits = self.stats['memory_hits'] + self.stats['disk_hits']
        
        return {
            **self.stats,
            'total_hits': total_hits,
            'overall_hit_rate': total_hits / total if total > 0 else 0.0,
            'memory_size': self.memory_cache.size() if self.memory_cache else 0
        }


# Test
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    
    cache = EmbeddingCache()
    
    # Test
    test_emb = np.random.randn(768).astype(np.float32)
    
    cache.put("test-001", test_emb)
    retrieved = cache.get("test-001")
    
    print(f"Put and retrieved: {retrieved is not None}")
    print(f"Stats: {cache.get_stats()}")
