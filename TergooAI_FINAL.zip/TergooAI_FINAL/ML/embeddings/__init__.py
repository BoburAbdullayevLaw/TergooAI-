"""
Embeddings Module
=================
Embedding generation and caching.

Author: TergooAI Team
"""

from .generator import EmbeddingGenerator
from .models import EmbeddingModel, ModelRegistry

__version__ = "1.0.0"
__all__ = ['EmbeddingGenerator', 'EmbeddingModel', 'ModelRegistry']
