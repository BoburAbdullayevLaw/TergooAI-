"""
Embedding Generator
===================
Document embedding generation.
EMOJI SAQLANADI!

Author: TergooAI Team
"""

import numpy as np
from typing import List, Dict, Any
import logging
from tqdm import tqdm

from .models import EmbeddingModel
from ..preprocessing.text_cleaner import TextCleaner
from ..utils.config import MLConfig

logger = logging.getLogger(__name__)


class EmbeddingGenerator:
    """Document embedding generator."""
    
    def __init__(self, model_name: str = None, config: MLConfig = None):
        """Initialize generator."""
        self.config = config or MLConfig()
        self.model_name = model_name or self.config.EMBEDDING['MODEL_NAME']
        self.model = EmbeddingModel(model_name=self.model_name, config=self.config)
        self.cleaner = TextCleaner()
        logger.info(f"EmbeddingGenerator initialized: {self.model_name}")
    
    def generate_document_embedding(self, document: Dict[str, Any]) -> np.ndarray:
        """Generate embedding for single document."""
        text_parts = self._extract_text(document)
        combined_text = ' '.join(text_parts)
        clean_text = self.cleaner.clean_text(combined_text)
        embedding = self.model.encode(clean_text)
        return embedding
    
    def _extract_text(self, document: Dict[str, Any]) -> List[str]:
        """Extract text from document."""
        texts = []
        fields = [
            'asosiy_matn', 'emoji_sarlavha', 'tushuntirish',
            'sharh', 'mazmuni', 'tavsif', 'izoh', 'qisqacha_tavsif'
        ]
        for field in fields:
            if field in document and document[field]:
                value = document[field]
                if isinstance(value, str):
                    texts.append(value)
        return texts
    
    def generate_batch_embeddings(
        self, documents: List[Dict[str, Any]], show_progress: bool = True
    ) -> Dict[str, np.ndarray]:
        """Generate embeddings for multiple documents."""
        logger.info(f"Generating embeddings for {len(documents)} documents...")
        results = {}
        iterator = tqdm(documents, desc="Embeddings") if show_progress else documents
        
        for doc in iterator:
            doc_id = doc.get('id', 'unknown')
            try:
                embedding = self.generate_document_embedding(doc)
                results[doc_id] = embedding
            except Exception as e:
                logger.error(f"Error for {doc_id}: {e}")
                results[doc_id] = np.zeros(self.model.dimension)
        
        logger.info(f"✅ Generated {len(results)} embeddings")
        return results
    
    def generate_query_embedding(self, query: str) -> np.ndarray:
        """Generate embedding for user query."""
        clean_query = self.cleaner.clean_text(query)
        embedding = self.model.encode(clean_query)
        return embedding
