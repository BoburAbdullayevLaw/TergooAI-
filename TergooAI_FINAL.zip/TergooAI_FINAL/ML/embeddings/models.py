"""
Embedding Models Module
=======================
Embedding modellarini boshqarish va yuklash.

Author: TergooAI Team
Date: 2024
"""

import torch
from sentence_transformers import SentenceTransformer
from typing import List, Union, Optional, Dict, Any
import numpy as np
from pathlib import Path
import logging
from dataclasses import dataclass
import time

# Local imports
from ..utils.config import MLConfig
from ..utils.logger import MLLogger

# Logger
logger = MLLogger.get_logger(__name__)


@dataclass
class ModelInfo:
    """Model haqida ma'lumot."""
    name: str
    dimension: int
    max_seq_length: int
    languages: List[str]
    speed: str  # 'fast', 'medium', 'slow'
    quality: str  # 'high', 'medium', 'low'
    memory_mb: int
    recommended: bool = False


class ModelRegistry:
    """
    Mavjud modellar ro'yxati va ma'lumotlari.
    """
    
    MODELS = {
        # ⭐ TAVSIYA: Multilingual, yaxshi balance
        "paraphrase-multilingual-mpnet-base-v2": ModelInfo(
            name="paraphrase-multilingual-mpnet-base-v2",
            dimension=768,
            max_seq_length=512,
            languages=["en", "ru", "uz", "de", "fr", "es", "it", "nl", "pl", "pt", "zh"],
            speed="medium",
            quality="high",
            memory_mb=420,
            recommended=True
        ),
        
        # Tez, kichik
        "all-MiniLM-L6-v2": ModelInfo(
            name="all-MiniLM-L6-v2",
            dimension=384,
            max_seq_length=256,
            languages=["en"],
            speed="fast",
            quality="medium",
            memory_mb=80,
            recommended=False
        ),
        
        # Juda yaxshi quality, sekinroq
        "intfloat/multilingual-e5-large": ModelInfo(
            name="intfloat/multilingual-e5-large",
            dimension=1024,
            max_seq_length=512,
            languages=["en", "ru", "uz", "ar", "zh", "de", "es", "fr", "hi", "it", "ja", "ko", "pt"],
            speed="slow",
            quality="high",
            memory_mb=1200,
            recommended=False
        ),
        
        # Russian-specific (agar kerak bo'lsa)
        "cointegrated/rubert-tiny2": ModelInfo(
            name="cointegrated/rubert-tiny2",
            dimension=312,
            max_seq_length=512,
            languages=["ru"],
            speed="fast",
            quality="medium",
            memory_mb=110,
            recommended=False
        ),
        
        # Multilingual BERT
        "distiluse-base-multilingual-cased-v2": ModelInfo(
            name="distiluse-base-multilingual-cased-v2",
            dimension=512,
            max_seq_length=512,
            languages=["en", "ru", "de", "fr", "es", "it", "nl", "pl", "pt", "ar", "zh"],
            speed="fast",
            quality="medium",
            memory_mb=250,
            recommended=False
        )
    }
    
    @classmethod
    def get_model_info(cls, model_name: str) -> Optional[ModelInfo]:
        """Model ma'lumotini olish."""
        return cls.MODELS.get(model_name)
    
    @classmethod
    def get_recommended_model(cls) -> str:
        """Tavsiya etilgan modelni olish."""
        for name, info in cls.MODELS.items():
            if info.recommended:
                return name
        return list(cls.MODELS.keys())[0]
    
    @classmethod
    def list_models(cls) -> List[str]:
        """Barcha modellar ro'yxati."""
        return list(cls.MODELS.keys())


class EmbeddingModel:
    """
    Embedding model wrapper.
    
    Features:
    - Model yuklash va cache qilish
    - Batch encoding
    - GPU/CPU optimizatsiya
    - Model ma'lumotlari
    """
    
    def __init__(
        self,
        model_name: str = None,
        device: str = None,
        config: MLConfig = None
    ):
        """
        Initialize Embedding Model.
        
        Args:
            model_name: Model nomi (default: config dan)
            device: 'cuda', 'cpu', yoki None (auto)
            config: ML konfiguratsiya
        """
        self.config = config or MLConfig()
        self.model_name = model_name or self.config.EMBEDDING['MODEL_NAME']
        
        # Model info
        self.model_info = ModelRegistry.get_model_info(self.model_name)
        if not self.model_info:
            logger.warning(f"Model info not found for {self.model_name}. Using defaults.")
            self.model_info = ModelInfo(
                name=self.model_name,
                dimension=768,
                max_seq_length=512,
                languages=["en"],
                speed="unknown",
                quality="unknown",
                memory_mb=0
            )
        
        # Device
        self.device = device or self._auto_detect_device()
        
        # Load model
        self.model = self._load_model()
        
        # Statistics
        self.encode_count = 0
        self.total_encode_time = 0.0
        
        logger.info(f"EmbeddingModel loaded: {self.model_name} on {self.device}")
        logger.info(f"  Dimension: {self.dimension}")
        logger.info(f"  Max Length: {self.max_seq_length}")
        logger.info(f"  Languages: {', '.join(self.model_info.languages)}")
    
    
    @property
    def dimension(self) -> int:
        """Embedding dimension."""
        return self.model_info.dimension
    
    @property
    def max_seq_length(self) -> int:
        """Maximum sequence length."""
        return self.model_info.max_seq_length
    
    
    def _auto_detect_device(self) -> str:
        """Device avtomatik aniqlash."""
        if torch.cuda.is_available():
            logger.info("CUDA available. Using GPU.")
            return "cuda"
        else:
            logger.info("CUDA not available. Using CPU.")
            return "cpu"
    
    
    def _load_model(self) -> SentenceTransformer:
        """
        Modelni yuklash.
        
        Returns:
            SentenceTransformer: Yuklangan model
        """
        logger.info(f"Loading model: {self.model_name}...")
        start_time = time.time()
        
        try:
            model = SentenceTransformer(self.model_name, device=self.device)
            
            # Max sequence length o'rnatish
            if hasattr(model, 'max_seq_length'):
                model.max_seq_length = self.max_seq_length
            
            elapsed = time.time() - start_time
            logger.info(f"Model loaded successfully in {elapsed:.2f}s")
            
            return model
            
        except Exception as e:
            logger.error(f"Error loading model: {e}")
            raise
    
    
    def encode(
        self,
        texts: Union[str, List[str]],
        batch_size: int = 32,
        show_progress_bar: bool = False,
        normalize: bool = True
    ) -> Union[np.ndarray, List[np.ndarray]]:
        """
        Matnlarni encode qilish (embedding yaratish).
        
        Args:
            texts: Bitta matn yoki matnlar ro'yxati
            batch_size: Batch hajmi
            show_progress_bar: Progress bar ko'rsatish
            normalize: L2 normalizatsiya
        
        Returns:
            numpy.ndarray yoki List[numpy.ndarray]: Embeddinglar
        
        Example:
            >>> model = EmbeddingModel()
            >>> embedding = model.encode("JK 97 nima?")
            >>> print(embedding.shape)  # (768,)
            >>> 
            >>> embeddings = model.encode(["Savol 1", "Savol 2"])
            >>> print(embeddings.shape)  # (2, 768)
        """
        start_time = time.time()
        
        # Single text
        single_input = isinstance(texts, str)
        if single_input:
            texts = [texts]
        
        # Encode
        embeddings = self.model.encode(
            texts,
            batch_size=batch_size,
            show_progress_bar=show_progress_bar,
            convert_to_numpy=True,
            normalize_embeddings=normalize
        )
        
        # Statistics
        elapsed = time.time() - start_time
        self.encode_count += len(texts)
        self.total_encode_time += elapsed
        
        # Return
        if single_input:
            return embeddings[0]
        return embeddings
    
    
    def similarity(
        self,
        embedding1: np.ndarray,
        embedding2: np.ndarray,
        metric: str = 'cosine'
    ) -> float:
        """
        Ikki embedding o'rtasidagi o'xshashlik.
        
        Args:
            embedding1: Birinchi embedding
            embedding2: Ikkinchi embedding
            metric: 'cosine', 'dot', 'euclidean'
        
        Returns:
            float: Similarity score
        
        Example:
            >>> emb1 = model.encode("JK 97")
            >>> emb2 = model.encode("Qasddan odam o'ldirish")
            >>> similarity = model.similarity(emb1, emb2)
            >>> print(f"Similarity: {similarity:.4f}")
        """
        if metric == 'cosine':
            # Cosine similarity
            from numpy.linalg import norm
            return np.dot(embedding1, embedding2) / (norm(embedding1) * norm(embedding2))
        
        elif metric == 'dot':
            # Dot product
            return np.dot(embedding1, embedding2)
        
        elif metric == 'euclidean':
            # Euclidean distance (inverted for similarity)
            distance = np.linalg.norm(embedding1 - embedding2)
            return 1 / (1 + distance)  # Convert to similarity
        
        else:
            raise ValueError(f"Unknown metric: {metric}")
    
    
    def batch_similarity(
        self,
        query_embedding: np.ndarray,
        corpus_embeddings: np.ndarray,
        metric: str = 'cosine'
    ) -> np.ndarray:
        """
        Bitta query bilan ko'p corpuslar orasidagi similarity.
        
        Args:
            query_embedding: Query embedding (768,)
            corpus_embeddings: Corpus embeddings (N, 768)
            metric: Similarity metric
        
        Returns:
            np.ndarray: Similarity scores (N,)
        """
        if metric == 'cosine':
            # Vectorized cosine similarity
            from numpy.linalg import norm
            
            # Normalize
            query_norm = query_embedding / norm(query_embedding)
            corpus_norms = corpus_embeddings / norm(corpus_embeddings, axis=1, keepdims=True)
            
            # Dot product
            similarities = np.dot(corpus_norms, query_norm)
            return similarities
        
        elif metric == 'dot':
            return np.dot(corpus_embeddings, query_embedding)
        
        elif metric == 'euclidean':
            distances = np.linalg.norm(corpus_embeddings - query_embedding, axis=1)
            return 1 / (1 + distances)
        
        else:
            raise ValueError(f"Unknown metric: {metric}")
    
    
    def get_info(self) -> Dict[str, Any]:
        """Model haqida to'liq ma'lumot."""
        return {
            'name': self.model_name,
            'dimension': self.dimension,
            'max_seq_length': self.max_seq_length,
            'device': self.device,
            'languages': self.model_info.languages,
            'speed': self.model_info.speed,
            'quality': self.model_info.quality,
            'memory_mb': self.model_info.memory_mb,
            'encode_count': self.encode_count,
            'total_time': self.total_encode_time,
            'avg_time_per_text': self.total_encode_time / max(1, self.encode_count)
        }
    
    
    def benchmark(
        self,
        num_texts: int = 100,
        text_length: int = 50
    ) -> Dict[str, float]:
        """
        Model benchmark (speed test).
        
        Args:
            num_texts: Test matnlar soni
            text_length: Har bir matn uzunligi (so'zlar)
        
        Returns:
            Dict[str, float]: Benchmark natijalar
        """
        logger.info(f"Running benchmark: {num_texts} texts, {text_length} words each")
        
        # Generate test texts
        import random
        import string
        
        def generate_text(length):
            words = [''.join(random.choices(string.ascii_lowercase, k=random.randint(3, 10))) 
                     for _ in range(length)]
            return ' '.join(words)
        
        test_texts = [generate_text(text_length) for _ in range(num_texts)]
        
        # Benchmark
        start_time = time.time()
        embeddings = self.encode(test_texts, show_progress_bar=True)
        elapsed = time.time() - start_time
        
        # Results
        results = {
            'total_texts': num_texts,
            'text_length': text_length,
            'total_time': elapsed,
            'time_per_text': elapsed / num_texts,
            'texts_per_second': num_texts / elapsed,
            'embedding_dimension': embeddings.shape[1] if len(embeddings.shape) > 1 else self.dimension
        }
        
        logger.info(f"Benchmark complete: {results['texts_per_second']:.2f} texts/sec")
        
        return results
    
    
    def save_model(self, path: Path):
        """
        Modelni saqlash (local copy).
        
        Args:
            path: Saqlash yo'li
        """
        path = Path(path)
        path.mkdir(parents=True, exist_ok=True)
        
        self.model.save(str(path))
        logger.info(f"Model saved to {path}")
    
    
    @classmethod
    def compare_models(
        cls,
        model_names: List[str],
        test_texts: List[str]
    ) -> Dict[str, Dict[str, Any]]:
        """
        Modellarni taqqoslash.
        
        Args:
            model_names: Modellar ro'yxati
            test_texts: Test matnlari
        
        Returns:
            Dict[str, Dict]: Model -> metrics
        """
        results = {}
        
        for model_name in model_names:
            logger.info(f"Testing model: {model_name}")
            
            try:
                model = cls(model_name=model_name)
                
                # Speed test
                start_time = time.time()
                embeddings = model.encode(test_texts)
                elapsed = time.time() - start_time
                
                results[model_name] = {
                    'dimension': model.dimension,
                    'total_time': elapsed,
                    'time_per_text': elapsed / len(test_texts),
                    'texts_per_second': len(test_texts) / elapsed,
                    'memory_mb': model.model_info.memory_mb
                }
                
            except Exception as e:
                logger.error(f"Error testing {model_name}: {e}")
                results[model_name] = {'error': str(e)}
        
        return results


# ============================================================================
# EXAMPLE USAGE
# ============================================================================

if __name__ == "__main__":
    import logging
    
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # 1. List available models
    print("\n📋 Available Models:")
    print("=" * 60)
    for model_name in ModelRegistry.list_models():
        info = ModelRegistry.get_model_info(model_name)
        star = "⭐" if info.recommended else "  "
        print(f"{star} {model_name}")
        print(f"   - Dimension: {info.dimension}, Speed: {info.speed}, Quality: {info.quality}")
        print(f"   - Languages: {', '.join(info.languages[:5])}...")
        print()
    
    # 2. Load recommended model
    print("\n🤖 Loading Recommended Model:")
    print("=" * 60)
    model = EmbeddingModel()
    
    # 3. Encode single text
    print("\n📝 Single Text Encoding:")
    text = "JK 97-2(a) - ikki yoki undan ortiq shaxsni qasddan o'ldirish"
    embedding = model.encode(text)
    print(f"Text: '{text}'")
    print(f"Embedding shape: {embedding.shape}")
    print(f"First 5 values: {embedding[:5]}")
    
    # 4. Encode batch
    print("\n📚 Batch Encoding:")
    texts = [
        "Qasddan odam o'ldirish",
        "Og'irlashtiruvchi holatlar",
        "JK 97-2(a) nima?"
    ]
    embeddings = model.encode(texts)
    print(f"Number of texts: {len(texts)}")
    print(f"Embeddings shape: {embeddings.shape}")
    
    # 5. Similarity
    print("\n🔍 Similarity:")
    emb1 = model.encode("JK 97-2(a)")
    emb2 = model.encode("Ikki odamni o'ldirish")
    similarity = model.similarity(emb1, emb2)
    print(f"Text 1: 'JK 97-2(a)'")
    print(f"Text 2: 'Ikki odamni o'ldirish'")
    print(f"Similarity: {similarity:.4f}")
    
    # 6. Model info
    print("\n📊 Model Info:")
    print("=" * 60)
    info = model.get_info()
    for key, value in info.items():
        print(f"{key}: {value}")
