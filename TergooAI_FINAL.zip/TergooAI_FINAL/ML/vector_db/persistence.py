"""
Index Persistence Module
========================
Indexni saqlash va yuklash.

Author: TergooAI Team
"""

from pathlib import Path
import shutil
from datetime import datetime
import logging

logger = logging.getLogger(__name__)


class IndexPersistence:
    """Index persistence utilities."""
    
    def __init__(self, base_dir: Path = None):
        """
        Initialize Index Persistence.
        
        Args:
            base_dir: Base directory for indices
        """
        self.base_dir = base_dir or Path("data/faiss_index")
        self.base_dir.mkdir(parents=True, exist_ok=True)
        logger.info(f"IndexPersistence initialized: {self.base_dir}")
    
    def save_index(self, vector_db, index_name: str = "main"):
        """
        Save index to disk.
        
        Args:
            vector_db: FAISS database instance
            index_name: Index name
        """
        index_path = self.base_dir / index_name
        vector_db.save(index_path)
        logger.info(f"✅ Index saved: {index_path}")
    
    def load_index(self, vector_db, index_name: str = "main"):
        """
        Load index from disk.
        
        Args:
            vector_db: FAISS database instance
            index_name: Index name
        
        Returns:
            FAISS database with loaded index
        """
        index_path = self.base_dir / index_name
        
        if not index_path.exists():
            raise FileNotFoundError(f"Index not found: {index_path}")
        
        vector_db.load(index_path)
        logger.info(f"✅ Index loaded: {index_path}")
        
        return vector_db
    
    def create_backup(self, index_name: str = "main"):
        """
        Create backup of index.
        
        Args:
            index_name: Index name
        """
        index_path = self.base_dir / index_name
        
        if not index_path.exists():
            logger.warning(f"Index not found for backup: {index_path}")
            return
        
        # Backup directory
        backup_dir = self.base_dir / "backups"
        backup_dir.mkdir(exist_ok=True)
        
        # Backup name with timestamp
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_name = f"{index_name}_backup_{timestamp}"
        backup_path = backup_dir / backup_name
        
        # Copy index
        shutil.copytree(index_path, backup_path)
        
        logger.info(f"✅ Backup created: {backup_path}")


# Test
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    print("Index Persistence - Save, load, and backup FAISS indices")
