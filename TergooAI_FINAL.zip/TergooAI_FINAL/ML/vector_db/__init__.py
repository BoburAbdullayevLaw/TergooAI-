"""Vector Database Module"""
from .faiss_db import FAISSDatabase
__all__ = ['FAISSDatabase']
