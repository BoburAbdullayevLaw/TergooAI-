"""FAISS Database"""
import numpy as np
import faiss
from typing import List, Dict, Any, Tuple
from pathlib import Path
import pickle
import logging

logger = logging.getLogger(__name__)

class FAISSDatabase:
    """FAISS vector database."""
    def __init__(self, dimension: int = 768, index_type: str = 'Flat', metric: str = 'L2'):
        self.dimension = dimension
        self.index_type = index_type
        self.metric = metric
        self.index = self._create_index()
        self.id_to_doc: Dict[int, str] = {}
        self.doc_to_id: Dict[str, int] = {}
        logger.info(f"FAISSDatabase initialized: {index_type}, dim={dimension}")
    
    def _create_index(self) -> faiss.Index:
        if self.metric == 'L2':
            return faiss.IndexFlatL2(self.dimension)
        else:
            return faiss.IndexFlatIP(self.dimension)
    
    def add_vectors(self, embeddings: np.ndarray, doc_ids: List[str]):
        if self.metric == 'IP':
            faiss.normalize_L2(embeddings)
        start_id = self.index.ntotal
        self.index.add(embeddings)
        for i, doc_id in enumerate(doc_ids):
            idx = start_id + i
            self.id_to_doc[idx] = doc_id
            self.doc_to_id[doc_id] = idx
        logger.info(f"Added {len(embeddings)} vectors. Total: {self.index.ntotal}")
    
    def search(self, query_vector: np.ndarray, k: int = 5) -> Tuple[List[str], List[float]]:
        if query_vector.ndim == 1:
            query_vector = query_vector.reshape(1, -1)
        if self.metric == 'IP':
            faiss.normalize_L2(query_vector)
        distances, indices = self.index.search(query_vector, k)
        doc_ids = []
        valid_distances = []
        for idx, dist in zip(indices[0], distances[0]):
            if idx != -1 and idx in self.id_to_doc:
                doc_ids.append(self.id_to_doc[idx])
                valid_distances.append(float(dist))
        return doc_ids, valid_distances
    
    def save(self, path: Path):
        path = Path(path)
        path.mkdir(parents=True, exist_ok=True)
        faiss.write_index(self.index, str(path / "faiss.index"))
        metadata = {
            'id_to_doc': self.id_to_doc,
            'doc_to_id': self.doc_to_id,
            'dimension': self.dimension,
            'index_type': self.index_type,
            'metric': self.metric
        }
        with open(path / "metadata.pkl", 'wb') as f:
            pickle.dump(metadata, f)
        logger.info(f"Saved index to {path}")
    
    def load(self, path: Path):
        path = Path(path)
        self.index = faiss.read_index(str(path / "faiss.index"))
        with open(path / "metadata.pkl", 'rb') as f:
            metadata = pickle.load(f)
        self.id_to_doc = metadata['id_to_doc']
        self.doc_to_id = metadata['doc_to_id']
        self.dimension = metadata['dimension']
        self.index_type = metadata['index_type']
        self.metric = metadata['metric']
        logger.info(f"Loaded index from {path}")
    
    def get_stats(self) -> Dict[str, Any]:
        return {
            'total_vectors': self.index.ntotal,
            'dimension': self.dimension,
            'index_type': self.index_type,
            'metric': self.metric
        }
