"""
Index Management Module
=======================
Index yaratish va boshqarish.

Author: TergooAI Team
"""

import numpy as np
from typing import List, Dict, Any
from pathlib import Path
import logging

logger = logging.getLogger(__name__)


class IndexManager:
    """Index management utilities."""
    
    def __init__(self, embedding_generator, dimension: int = 768):
        """
        Initialize Index Manager.
        
        Args:
            embedding_generator: Embedding generator instance
            dimension: Embedding dimension
        """
        self.generator = embedding_generator
        self.dimension = dimension
        logger.info("IndexManager initialized")
    
    def build_index(self, documents: List[Dict[str, Any]], vector_db):
        """
        Build FAISS index from documents.
        
        Args:
            documents: List of documents
            vector_db: FAISS database instance
        
        Returns:
            FAISS database with vectors added
        """
        logger.info(f"Building index for {len(documents)} documents...")
        
        # Generate embeddings
        embeddings_dict = self.generator.generate_batch_embeddings(
            documents,
            show_progress=True
        )
        
        # Convert to numpy array
        doc_ids = list(embeddings_dict.keys())
        embeddings = np.array([embeddings_dict[did] for did in doc_ids])
        
        # Add to database
        vector_db.add_vectors(embeddings, doc_ids)
        
        logger.info(f"✅ Index built: {vector_db.index.ntotal} vectors")
        
        return vector_db
    
    def update_index(self, document: Dict[str, Any], vector_db):
        """
        Update index with new document.
        
        Args:
            document: New document
            vector_db: FAISS database instance
        """
        logger.info(f"Updating index with {document.get('id')}...")
        
        embedding = self.generator.generate_document_embedding(document)
        doc_id = document['id']
        
        vector_db.add_vectors(embedding.reshape(1, -1), [doc_id])
        
        logger.info("✅ Index updated")


# Test
if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO)
    print("Index Manager - Build and update FAISS indices")
