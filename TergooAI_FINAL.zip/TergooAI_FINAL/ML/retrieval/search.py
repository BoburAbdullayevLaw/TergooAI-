"""Semantic Search"""
import numpy as np
from typing import List, Dict, Any
from dataclasses import dataclass
import logging

logger = logging.getLogger(__name__)

@dataclass
class SearchResult:
    sharx_id: str
    score: float
    sharx_data: Dict[str, Any] = None
    rank: int = 0

class SemanticSearch:
    """Semantic search engine."""
    def __init__(self, embedding_generator, vector_db, documents_data, config=None):
        self.generator = embedding_generator
        self.db = vector_db
        self.documents_data = documents_data
        self.config = config
        logger.info("SemanticSearch initialized")
    
    def search(self, query: str, top_k: int = 5, threshold: float = 0.6, include_data: bool = True) -> List[SearchResult]:
        query_embedding = self.generator.generate_query_embedding(query)
        doc_ids, distances = self.db.search(query_embedding, k=top_k * 2)
        similarities = [1.0 - (d**2 / 2.0) for d in distances]
        similarities = [max(0.0, min(1.0, s)) for s in similarities]
        results = []
        for doc_id, similarity in zip(doc_ids, similarities):
            if similarity >= threshold:
                result = SearchResult(sharx_id=doc_id, score=similarity)
                if include_data and doc_id in self.documents_data:
                    result.sharx_data = self.documents_data[doc_id]
                results.append(result)
        results.sort(key=lambda x: x.score, reverse=True)
        for i, result in enumerate(results[:top_k]):
            result.rank = i + 1
        logger.info(f"Search '{query}': found {len(results[:top_k])} results")
        return results[:top_k]
    
    def get_stats(self) -> Dict[str, Any]:
        return self.db.get_stats()
