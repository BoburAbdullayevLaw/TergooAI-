"""
Helper Functions
================
Yordamchi funksiyalar.

Author: TergooAI Team
"""

import numpy as np
from typing import Any, List
import time
from functools import wraps


class MLHelpers:
    """ML utility functions."""
    
    @staticmethod
    def cosine_similarity(vec1: np.ndarray, vec2: np.ndarray) -> float:
        """Calculate cosine similarity."""
        return np.dot(vec1, vec2) / (np.linalg.norm(vec1) * np.linalg.norm(vec2))
    
    @staticmethod
    def normalize_vector(vec: np.ndarray) -> np.ndarray:
        """Normalize vector to unit length."""
        norm = np.linalg.norm(vec)
        return vec / norm if norm > 0 else vec
    
    @staticmethod
    def batch_process(items: List[Any], batch_size: int, process_fn) -> List[Any]:
        """Process items in batches."""
        results = []
        for i in range(0, len(items), batch_size):
            batch = items[i:i + batch_size]
            results.extend(process_fn(batch))
        return results
    
    @staticmethod
    def measure_time(func):
        """Decorator to measure execution time."""
        @wraps(func)
        def wrapper(*args, **kwargs):
            start = time.time()
            result = func(*args, **kwargs)
            elapsed = time.time() - start
            print(f"{func.__name__} took {elapsed:.4f}s")
            return result
        return wrapper


# Test
if __name__ == "__main__":
    helpers = MLHelpers()
    
    vec1 = np.array([1, 2, 3])
    vec2 = np.array([4, 5, 6])
    
    similarity = helpers.cosine_similarity(vec1, vec2)
    print(f"Cosine similarity: {similarity:.4f}")
