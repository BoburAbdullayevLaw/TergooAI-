"""
ML Logger
=========
Logging system.

Author: TergooAI Team
Date: 2024
"""

import logging
from pathlib import Path
from datetime import datetime


class MLLogger:
    """ML logging system."""
    
    _loggers = {}
    
    @classmethod
    def get_logger(cls, name: str, log_dir: Path = None) -> logging.Logger:
        """Get or create logger."""
        if name in cls._loggers:
            return cls._loggers[name]
        
        logger = logging.getLogger(name)
        logger.setLevel(logging.INFO)
        
        # Console handler
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)
        
        cls._loggers[name] = logger
        return logger
