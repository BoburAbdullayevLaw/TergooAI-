"""
ML Configuration
================
ML sistema konfiguratsiyasi.

Author: TergooAI Team
Date: 2024
"""

from dataclasses import dataclass, field
from typing import Dict, Any
from pathlib import Path


@dataclass
class MLConfig:
    """ML system configuration."""
    
    # Embedding settings
    EMBEDDING: Dict[str, Any] = field(default_factory=lambda: {
        'MODEL_NAME': 'paraphrase-multilingual-mpnet-base-v2',
        'DIMENSION': 768,
        'MAX_LENGTH': 512,
        'BATCH_SIZE': 32,
        'NORMALIZE': True
    })
    
    # Search settings
    SEARCH: Dict[str, Any] = field(default_factory=lambda: {
        'TOP_K': 5,
        'SIMILARITY_THRESHOLD': 0.6,
        'MAX_RESULTS': 20
    })
    
    # FAISS settings
    FAISS: Dict[str, Any] = field(default_factory=lambda: {
        'INDEX_TYPE': 'Flat',
        'METRIC': 'L2'
    })
    
    # Paths
    PATHS: Dict[str, str] = field(default_factory=lambda: {
        'DATA_DIR': 'data',
        'JK_DIR': 'data/JK',
        'JPK_DIR': 'data/JPK',
        'KRIM_DIR': 'data/kriminalistika',
        'INDEX_DIR': 'data/faiss_index',
        'CACHE_DIR': 'data/cache',
        'LOGS_DIR': 'logs'
    })
