"""System Test"""
import logging
logging.basicConfig(level=logging.INFO)

def test_imports():
    """Test all imports."""
    print("\n" + "="*60)
    print("TESTING IMPORTS")
    print("="*60)
    
    try:
        from database import DataLoader
        print("✅ database.py OK")
    except Exception as e:
        print(f"❌ database.py ERROR: {e}")
    
    try:
        from ML.utils import MLConfig, MLLogger
        print("✅ ML.utils OK")
    except Exception as e:
        print(f"❌ ML.utils ERROR: {e}")
    
    try:
        from ML.preprocessing import TextCleaner
        print("✅ ML.preprocessing OK")
    except Exception as e:
        print(f"❌ ML.preprocessing ERROR: {e}")
    
    try:
        from ML.embeddings import EmbeddingGenerator, EmbeddingModel
        print("✅ ML.embeddings OK")
    except Exception as e:
        print(f"❌ ML.embeddings ERROR: {e}")
    
    try:
        from ML.vector_db import FAISSDatabase
        print("✅ ML.vector_db OK")
    except Exception as e:
        print(f"❌ ML.vector_db ERROR: {e}")
    
    try:
        from ML.retrieval import SemanticSearch
        print("✅ ML.retrieval OK")
    except Exception as e:
        print(f"❌ ML.retrieval ERROR: {e}")
    
    print("="*60)
    print("✅ IMPORT TEST COMPLETE")
    print("="*60)

if __name__ == "__main__":
    test_imports()
