# 📚 TergooAI API Documentation

**Version:** 1.0.0  
**Base URL:** `http://localhost:8000`

---

## 🎯 Overview

TergooAI provides a semantic search API for legal documents including:
- **JK** - Jinoyat Kodeksi (Criminal Code)
- **JPK** - Jinoyat-Protsessual Kodeks (Criminal Procedure Code)
- **Kriminalistika** - Criminalistic materials

---

## 🔐 Authentication

Currently, no authentication required (development mode).

---

## 📍 Endpoints

### 1. Root - Get API Info

```http
GET /
```

**Response:**
```json
{
  "message": "TergooAI API",
  "version": "1.0.0",
  "documents": {
    "total": 150,
    "JK": 100,
    "JPK": 30,
    "KRIM": 20
  }
}
```

---

### 2. Health Check

```http
GET /health
```

**Response:**
```json
{
  "status": "healthy",
  "ml_system": "ready",
  "database_size": 150,
  "timestamp": "2024-01-15T10:30:00"
}
```

---

### 3. Semantic Search

```http
POST /search
```

**Request Body:**
```json
{
  "query": "JK 97-2(a) nima?",
  "top_k": 5,
  "threshold": 0.6,
  "source_filter": "JK",
  "include_full_data": false
}
```

**Parameters:**
- `query` (required): Search query
- `top_k` (optional): Number of results (default: 5, max: 20)
- `threshold` (optional): Minimum similarity score (default: 0.6, range: 0-1)
- `source_filter` (optional): Filter by source: "JK", "JPK", or "KRIM"
- `include_full_data` (optional): Include full document data (default: false)

**Response:**
```json
{
  "query": "JK 97-2(a) nima?",
  "results": [
    {
      "id": "JK-097-SHARH-002",
      "score": 0.92,
      "rank": 1,
      "source": "JK",
      "modda_raqam": "97",
      "emoji_sarlavha": "👥 Ikki yoki undan ortiq shaxsni o'ldirish",
      "asosiy_matn": "JK 97-2(a): Ikki yoki undan ortiq shaxsni qasddan o'ldirish...",
      "full_data": null
    }
  ],
  "total_found": 1,
  "search_time_ms": 45.2,
  "timestamp": "2024-01-15T10:30:00"
}
```

---

### 4. Get Document by ID

```http
GET /document/{doc_id}
```

**Example:**
```http
GET /document/JK-097-SHARH-001
```

**Response:**
```json
{
  "id": "JK-097-SHARH-001",
  "source": "JK",
  "data": {
    "modda_raqam": "97",
    "emoji_sarlavha": "⚖️ Oddiy o'ldirish",
    "asosiy_matn": "...",
    ...
  }
}
```

---

### 5. Get Statistics

```http
GET /stats
```

**Response:**
```json
{
  "documents": {
    "total": 150,
    "JK": 100,
    "JPK": 30,
    "KRIM": 20
  },
  "database": {
    "total_vectors": 150,
    "dimension": 768,
    "index_type": "Flat"
  }
}
```

---

## 🧪 Example Usage

### cURL

```bash
# Search
curl -X POST "http://localhost:8000/search" \
  -H "Content-Type: application/json" \
  -d '{
    "query": "Qasddan odam o'\''ldirish",
    "top_k": 3,
    "threshold": 0.6
  }'

# Get document
curl "http://localhost:8000/document/JK-097-SHARH-001"

# Health check
curl "http://localhost:8000/health"
```

---

### Python

```python
import requests

# Search
response = requests.post(
    "http://localhost:8000/search",
    json={
        "query": "JK 97-2(a) nima?",
        "top_k": 5,
        "threshold": 0.6,
        "source_filter": "JK"
    }
)

results = response.json()
print(f"Found {results['total_found']} results")

for result in results['results']:
    print(f"{result['rank']}. {result['id']}: {result['score']:.2f}")
```

---

### JavaScript

```javascript
// Search
fetch('http://localhost:8000/search', {
  method: 'POST',
  headers: {
    'Content-Type': 'application/json',
  },
  body: JSON.stringify({
    query: 'JK 97 nima?',
    top_k: 5,
    threshold: 0.6
  })
})
.then(res => res.json())
.then(data => {
  console.log(`Found ${data.total_found} results`);
  data.results.forEach(result => {
    console.log(`${result.rank}. ${result.id}: ${result.score}`);
  });
});
```

---

## 📊 Response Codes

| Code | Description |
|------|-------------|
| 200 | Success |
| 400 | Bad Request (invalid parameters) |
| 404 | Not Found (document not found) |
| 500 | Internal Server Error |

---

## 🔍 Search Tips

1. **Use natural language**: "JK 97-2(a) nima?" works better than just "97-2"
2. **Emoji preserved**: Emojis in documents are preserved (⚖️ 👥 🔴)
3. **Threshold tuning**: 
   - 0.8-1.0: Very similar (strict)
   - 0.6-0.8: Similar (recommended)
   - 0.4-0.6: Somewhat related
   - 0.0-0.4: Loosely related
4. **Source filtering**: Use `source_filter` to search only in JK, JPK, or KRIM

---

## 📝 Notes

- All text fields support Unicode (including Cyrillic and emoji)
- Search is case-insensitive
- Whitespace is normalized automatically
- HTML tags are removed automatically

---

## 🚀 Interactive Documentation

Visit `http://localhost:8000/docs` for interactive Swagger UI documentation.

---

**Need help?** Contact: info@tergooai.uz
