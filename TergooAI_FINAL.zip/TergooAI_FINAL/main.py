"""
TergooAI Main Application
=========================
JK, JPK, Kriminalistika semantic search.

Author: TergooAI Team
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import List, Optional, Dict, Any
import logging
import time
from pathlib import Path
import numpy as np

from database import DataLoader
from ML.embeddings import EmbeddingGenerator
from ML.vector_db import FAISSDatabase
from ML.retrieval import SemanticSearch
from ML.utils import MLConfig

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# Initialize
logger.info("🚀 STARTING TERGOOAI")
data_loader = DataLoader("data")
all_data = data_loader.load_all()
documents_list = data_loader.get_all_documents_list()

if not all_data:
    logger.error("❌ No data loaded!")
    raise RuntimeError("No data found")

logger.info("🤖 Initializing ML system...")
generator = EmbeddingGenerator()

index_dir = Path("data/faiss_index")
index_path = index_dir / "main"
db = FAISSDatabase(dimension=768, index_type='Flat')

if index_path.exists():
    logger.info("📂 Loading existing index...")
    db.load(index_path)
else:
    logger.info("🔨 Building new index...")
    embeddings_dict = generator.generate_batch_embeddings(documents_list)
    doc_ids = list(embeddings_dict.keys())
    embeddings = np.array([embeddings_dict[did] for did in doc_ids])
    db.add_vectors(embeddings, doc_ids)
    db.save(index_path)

config = MLConfig()
search_engine = SemanticSearch(generator, db, all_data, config)
logger.info("✅ TERGOOAI READY")

# FastAPI
app = FastAPI(title="TergooAI API", description="JK, JPK, Kriminalistika semantic search", version="1.0.0")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

class SearchRequest(BaseModel):
    query: str
    top_k: Optional[int] = 5
    threshold: Optional[float] = 0.6
    source_filter: Optional[str] = None

class SearchResponse(BaseModel):
    query: str
    results: List[Dict[str, Any]]
    total_found: int
    search_time_ms: float

@app.get("/")
async def root():
    return {
        "message": "TergooAI API",
        "version": "1.0.0",
        "documents": {
            "total": len(all_data),
            "JK": len(data_loader.get_by_source('JK')),
            "JPK": len(data_loader.get_by_source('JPK')),
            "KRIM": len(data_loader.get_by_source('KRIM'))
        }
    }

@app.get("/health")
async def health():
    return {"status": "healthy", "database_size": db.get_stats()['total_vectors']}

@app.post("/search", response_model=SearchResponse)
async def search(request: SearchRequest):
    start_time = time.time()
    try:
        results = search_engine.search(request.query, top_k=request.top_k, threshold=request.threshold, include_data=True)
        if request.source_filter:
            results = [r for r in results if r.sharx_data and r.sharx_data.get('_source') == request.source_filter]
        formatted_results = [{"id": r.sharx_id, "score": r.score, "rank": r.rank, "source": r.sharx_data.get('_source'), "data": r.sharx_data} for r in results]
        search_time_ms = (time.time() - start_time) * 1000
        return SearchResponse(query=request.query, results=formatted_results, total_found=len(formatted_results), search_time_ms=search_time_ms)
    except Exception as e:
        logger.error(f"Search error: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/document/{doc_id}")
async def get_document(doc_id: str):
    doc = data_loader.get_document(doc_id)
    if not doc:
        raise HTTPException(status_code=404, detail="Document not found")
    return doc

@app.get("/stats")
async def get_stats():
    return {
        "documents": {"total": len(all_data), "JK": len(data_loader.get_by_source('JK')), "JPK": len(data_loader.get_by_source('JPK')), "KRIM": len(data_loader.get_by_source('KRIM'))},
        "database": db.get_stats()
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
