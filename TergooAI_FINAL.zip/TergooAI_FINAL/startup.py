"""
Application Startup
===================
Application initialization va startup handler.

Author: TergooAI Team
Date: 2024
"""

import sys
import time
from pathlib import Path
import logging

# Add project root to path
sys.path.insert(0, str(Path(__file__).parent))

from config import get_settings, ensure_directories
from database import DataLoader
from ML.embeddings import EmbeddingGenerator
from ML.vector_db import FAISSDatabase
from ML.retrieval import SemanticSearch
from ML.utils import MLConfig

logger = logging.getLogger(__name__)


class ApplicationStartup:
    """
    Application startup handler.
    """
    
    def __init__(self):
        """Initialize startup handler."""
        self.settings = get_settings()
        self.start_time = time.time()
        
        # Components
        self.data_loader = None
        self.generator = None
        self.db = None
        self.search_engine = None
        
        # Data
        self.all_data = {}
        self.documents_list = []
    
    
    def run(self):
        """Run complete startup sequence."""
        logger.info("=" * 70)
        logger.info("🚀 STARTING TERGOOAI APPLICATION")
        logger.info("=" * 70)
        
        try:
            # 1. Create directories
            self._create_directories()
            
            # 2. Load data
            self._load_data()
            
            # 3. Initialize ML components
            self._initialize_ml()
            
            # 4. Build/Load index
            self._setup_index()
            
            # 5. Initialize search engine
            self._initialize_search()
            
            # 6. Complete
            self._startup_complete()
            
            return True
            
        except Exception as e:
            logger.error(f"❌ Startup failed: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    
    def _create_directories(self):
        """Create necessary directories."""
        logger.info("📁 Creating directories...")
        ensure_directories()
        logger.info("   ✅ Directories ready")
    
    
    def _load_data(self):
        """Load all data from JK, JPK, kriminalistika."""
        logger.info("📂 Loading data from JK, JPK, kriminalistika...")
        
        self.data_loader = DataLoader(str(self.settings.DATA_DIR))
        self.all_data = self.data_loader.load_all()
        self.documents_list = self.data_loader.get_all_documents_list()
        
        if not self.all_data:
            raise RuntimeError("❌ No data loaded! Check data directories.")
        
        logger.info(f"   ✅ Loaded {len(self.all_data)} documents")
    
    
    def _initialize_ml(self):
        """Initialize ML components."""
        logger.info("🤖 Initializing ML components...")
        
        self.generator = EmbeddingGenerator(
            model_name=self.settings.EMBEDDING_MODEL
        )
        
        logger.info(f"   ✅ Embedding generator: {self.settings.EMBEDDING_MODEL}")
    
    
    def _setup_index(self):
        """Build or load FAISS index."""
        logger.info("🗄️ Setting up FAISS index...")
        
        index_path = self.settings.INDEX_DIR / "main"
        self.db = FAISSDatabase(
            dimension=self.settings.EMBEDDING_DIMENSION,
            index_type='Flat'
        )
        
        if index_path.exists():
            logger.info("   📂 Loading existing index...")
            self.db.load(index_path)
            logger.info(f"   ✅ Index loaded: {self.db.index.ntotal} vectors")
        else:
            logger.info("   🔨 Building new index...")
            
            import numpy as np
            embeddings_dict = self.generator.generate_batch_embeddings(
                self.documents_list,
                show_progress=True
            )
            
            doc_ids = list(embeddings_dict.keys())
            embeddings = np.array([embeddings_dict[did] for did in doc_ids])
            
            self.db.add_vectors(embeddings, doc_ids)
            self.db.save(index_path)
            
            logger.info(f"   ✅ Index built: {self.db.index.ntotal} vectors")
    
    
    def _initialize_search(self):
        """Initialize search engine."""
        logger.info("🔍 Initializing search engine...")
        
        ml_config = MLConfig()
        self.search_engine = SemanticSearch(
            embedding_generator=self.generator,
            vector_db=self.db,
            documents_data=self.all_data,
            config=ml_config
        )
        
        logger.info("   ✅ Search engine ready")
    
    
    def _startup_complete(self):
        """Startup completion message."""
        elapsed = time.time() - self.start_time
        
        logger.info("=" * 70)
        logger.info("✅ APPLICATION STARTED SUCCESSFULLY")
        logger.info(f"   Startup time: {elapsed:.2f}s")
        logger.info(f"   Environment: {self.settings.ENVIRONMENT}")
        logger.info(f"   API: {self.settings.API_HOST}:{self.settings.API_PORT}")
        logger.info(f"   Documents: {len(self.all_data)}")
        logger.info(f"   Vectors: {self.db.index.ntotal}")
        logger.info("=" * 70)
    
    
    def get_components(self):
        """
        Get initialized components.
        
        Returns:
            dict: All components
        """
        return {
            'data_loader': self.data_loader,
            'generator': self.generator,
            'db': self.db,
            'search_engine': self.search_engine,
            'all_data': self.all_data,
            'documents_list': self.documents_list
        }


# ============================================================================
# GLOBAL STARTUP
# ============================================================================

# Global startup instance
_startup_instance = None


def initialize_app():
    """
    Initialize application (called by main.py).
    
    Returns:
        dict: Initialized components
    """
    global _startup_instance
    
    if _startup_instance is None:
        _startup_instance = ApplicationStartup()
        success = _startup_instance.run()
        
        if not success:
            raise RuntimeError("Application startup failed")
    
    return _startup_instance.get_components()


def get_startup_instance():
    """Get startup instance."""
    return _startup_instance


# ============================================================================
# TEST
# ============================================================================

if __name__ == "__main__":
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Initialize
    components = initialize_app()
    
    # Test search
    print("\n" + "=" * 70)
    print("TESTING SEARCH")
    print("=" * 70)
    
    search_engine = components['search_engine']
    
    test_queries = [
        "JK 97 nima?",
        "Qasddan odam o'ldirish",
        "Ikki odamni o'ldirish"
    ]
    
    for query in test_queries:
        print(f"\nQuery: '{query}'")
        results = search_engine.search(query, top_k=3)
        
        for result in results:
            print(f"  {result.rank}. {result.sharx_id}: {result.score:.4f}")
    
    print("\n" + "=" * 70)
    print("✅ TEST COMPLETE")
    print("=" * 70)
