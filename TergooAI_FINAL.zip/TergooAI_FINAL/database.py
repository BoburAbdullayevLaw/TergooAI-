"""
Database Manager - Data Loader
===============================
JK, JPK, Kriminalistika ma'lumotlarini yuklash.

Features:
- ✅ 3 ta katalog: JK, JPK, kriminalistika
- ✅ Bo'sh katalog = xato yo'q (skip)
- ✅ JSON xato = skip
- ✅ Emoji SAQLANADI

Author: TergooAI Team
Date: 2024
"""

import json
from pathlib import Path
from typing import Dict, List, Any, Optional
import logging

logger = logging.getLogger(__name__)


class DataLoader:
    """
    Ma'lumotlar yuklovchisi.
    
    Yuklaydi:
    - data/JK/       -> Jinoyat Kodeksi
    - data/JPK/      -> Jinoyat-Protsessual Kodeks
    - data/kriminalistika/ -> Kriminalistika
    """
    
    def __init__(self, data_root: str = "data"):
        """
        Initialize Data Loader.
        
        Args:
            data_root: Data root directory (default: "data")
        """
        self.data_root = Path(data_root)
        
        # Data directories
        self.jk_dir = self.data_root / "JK"
        self.jpk_dir = self.data_root / "JPK"
        self.krim_dir = self.data_root / "kriminalistika"
        
        # Loaded data storage
        self.all_documents: Dict[str, Dict[str, Any]] = {}
        
        # Statistics
        self.stats = {
            'jk_count': 0,
            'jpk_count': 0,
            'krim_count': 0,
            'total': 0,
            'errors': 0
        }
        
        logger.info(f"DataLoader initialized: {data_root}")
    
    
    def load_all(self) -> Dict[str, Dict[str, Any]]:
        """
        Barcha kataloglardan ma'lumotlarni yuklash.
        
        Returns:
            Dict[str, Dict]: document_id -> document_data
        """
        logger.info("=" * 60)
        logger.info("📁 LOADING ALL DATA")
        logger.info("=" * 60)
        
        # Clear previous data
        self.all_documents.clear()
        self.stats = {
            'jk_count': 0,
            'jpk_count': 0,
            'krim_count': 0,
            'total': 0,
            'errors': 0
        }
        
        # Load JK
        self._load_jk()
        
        # Load JPK
        self._load_jpk()
        
        # Load Kriminalistika
        self._load_kriminalistika()
        
        # Final statistics
        self.stats['total'] = len(self.all_documents)
        
        logger.info("=" * 60)
        logger.info(f"✅ LOADING COMPLETE")
        logger.info(f"   Total: {self.stats['total']} documents")
        logger.info(f"   - JK:  {self.stats['jk_count']}")
        logger.info(f"   - JPK: {self.stats['jpk_count']}")
        logger.info(f"   - KRIM: {self.stats['krim_count']}")
        if self.stats['errors'] > 0:
            logger.warning(f"   ⚠️ Errors: {self.stats['errors']}")
        logger.info("=" * 60)
        
        return self.all_documents
    
    
    def _load_jk(self):
        """Load JK (Jinoyat Kodeksi) data."""
        logger.info("\n📂 Loading JK (Jinoyat Kodeksi)...")
        
        if not self.jk_dir.exists():
            logger.warning(f"   ⚠️ JK directory not found: {self.jk_dir}")
            return
        
        # Get all subdirectories (jk-097, jk-169, etc.)
        jk_moddalar = [d for d in self.jk_dir.iterdir() if d.is_dir()]
        
        if not jk_moddalar:
            logger.warning(f"   ⚠️ No subdirectories in JK")
            return
        
        for modda_dir in jk_moddalar:
            # Load all JSON files in this modda
            json_files = list(modda_dir.glob("*.json"))
            
            for json_file in json_files:
                try:
                    with open(json_file, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                    
                    # Ensure ID exists
                    if 'id' not in data:
                        data['id'] = f"JK-{modda_dir.name}-{json_file.stem}"
                    
                    # Add metadata
                    data['_source'] = 'JK'
                    data['_file'] = str(json_file)
                    data['_modda_dir'] = modda_dir.name
                    
                    # Store
                    doc_id = data['id']
                    self.all_documents[doc_id] = data
                    self.stats['jk_count'] += 1
                    
                except json.JSONDecodeError as e:
                    logger.error(f"   ❌ JSON error in {json_file.name}: {e}")
                    self.stats['errors'] += 1
                except Exception as e:
                    logger.error(f"   ❌ Error loading {json_file.name}: {e}")
                    self.stats['errors'] += 1
        
        logger.info(f"   ✅ Loaded {self.stats['jk_count']} JK documents")
    
    
    def _load_jpk(self):
        """Load JPK (Jinoyat-Protsessual Kodeks) data."""
        logger.info("\n📂 Loading JPK (Jinoyat-Protsessual Kodeks)...")
        
        if not self.jpk_dir.exists():
            logger.warning(f"   ⚠️ JPK directory not found: {self.jpk_dir}")
            return
        
        # Get all subdirectories
        jpk_moddalar = [d for d in self.jpk_dir.iterdir() if d.is_dir()]
        
        if not jpk_moddalar:
            logger.warning(f"   ⚠️ No subdirectories in JPK")
            return
        
        for modda_dir in jpk_moddalar:
            json_files = list(modda_dir.glob("*.json"))
            
            for json_file in json_files:
                try:
                    with open(json_file, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                    
                    if 'id' not in data:
                        data['id'] = f"JPK-{modda_dir.name}-{json_file.stem}"
                    
                    data['_source'] = 'JPK'
                    data['_file'] = str(json_file)
                    data['_modda_dir'] = modda_dir.name
                    
                    doc_id = data['id']
                    self.all_documents[doc_id] = data
                    self.stats['jpk_count'] += 1
                    
                except json.JSONDecodeError as e:
                    logger.error(f"   ❌ JSON error in {json_file.name}: {e}")
                    self.stats['errors'] += 1
                except Exception as e:
                    logger.error(f"   ❌ Error loading {json_file.name}: {e}")
                    self.stats['errors'] += 1
        
        logger.info(f"   ✅ Loaded {self.stats['jpk_count']} JPK documents")
    
    
    def _load_kriminalistika(self):
        """Load Kriminalistika data."""
        logger.info("\n📂 Loading Kriminalistika...")
        
        if not self.krim_dir.exists():
            logger.warning(f"   ⚠️ Kriminalistika directory not found: {self.krim_dir}")
            return
        
        # Get all subdirectories
        krim_dirs = [d for d in self.krim_dir.iterdir() if d.is_dir()]
        
        if not krim_dirs:
            logger.warning(f"   ⚠️ No subdirectories in kriminalistika")
            return
        
        for krim_subdir in krim_dirs:
            json_files = list(krim_subdir.glob("*.json"))
            
            for json_file in json_files:
                try:
                    with open(json_file, 'r', encoding='utf-8') as f:
                        data = json.load(f)
                    
                    if 'id' not in data:
                        data['id'] = f"KRIM-{krim_subdir.name}-{json_file.stem}"
                    
                    data['_source'] = 'KRIM'
                    data['_file'] = str(json_file)
                    data['_krim_dir'] = krim_subdir.name
                    
                    doc_id = data['id']
                    self.all_documents[doc_id] = data
                    self.stats['krim_count'] += 1
                    
                except json.JSONDecodeError as e:
                    logger.error(f"   ❌ JSON error in {json_file.name}: {e}")
                    self.stats['errors'] += 1
                except Exception as e:
                    logger.error(f"   ❌ Error loading {json_file.name}: {e}")
                    self.stats['errors'] += 1
        
        logger.info(f"   ✅ Loaded {self.stats['krim_count']} Kriminalistika documents")
    
    
    def get_by_source(self, source: str) -> Dict[str, Dict[str, Any]]:
        """
        Source bo'yicha filtrlash.
        
        Args:
            source: 'JK', 'JPK', yoki 'KRIM'
        
        Returns:
            Dict: Filtered documents
        """
        return {
            doc_id: doc
            for doc_id, doc in self.all_documents.items()
            if doc.get('_source') == source
        }
    
    
    def get_document(self, doc_id: str) -> Optional[Dict[str, Any]]:
        """
        Get document by ID.
        
        Args:
            doc_id: Document ID
        
        Returns:
            Dict or None: Document data
        """
        return self.all_documents.get(doc_id)
    
    
    def get_all_documents_list(self) -> List[Dict[str, Any]]:
        """
        Get all documents as list.
        
        Returns:
            List[Dict]: All documents
        """
        return list(self.all_documents.values())
    
    
    def search_by_modda(self, modda_raqam: str) -> List[Dict[str, Any]]:
        """
        Modda raqami bo'yicha qidirish.
        
        Args:
            modda_raqam: Modda raqami (masalan: "97")
        
        Returns:
            List[Dict]: Matching documents
        """
        results = []
        for doc in self.all_documents.values():
            if doc.get('modda_raqam') == modda_raqam:
                results.append(doc)
        return results
    
    
    def get_stats(self) -> Dict[str, Any]:
        """
        Get loading statistics.
        
        Returns:
            Dict: Statistics
        """
        return {
            **self.stats,
            'directories': {
                'jk_exists': self.jk_dir.exists(),
                'jpk_exists': self.jpk_dir.exists(),
                'krim_exists': self.krim_dir.exists()
            }
        }


# ============================================================================
# TEST
# ============================================================================

if __name__ == "__main__":
    import logging
    
    # Setup logging
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )
    
    # Create loader
    loader = DataLoader("data")
    
    # Load all
    all_data = loader.load_all()
    
    # Print summary
    print("\n" + "=" * 60)
    print("📊 DATA SUMMARY")
    print("=" * 60)
    
    stats = loader.get_stats()
    print(f"Total documents: {stats['total']}")
    print(f"  - JK:   {stats['jk_count']}")
    print(f"  - JPK:  {stats['jpk_count']}")
    print(f"  - KRIM: {stats['krim_count']}")
    
    if stats['errors'] > 0:
        print(f"  ⚠️ Errors: {stats['errors']}")
    
    # Show sample
    if all_data:
        print("\n📄 Sample document:")
        sample_id = list(all_data.keys())[0]
        sample_doc = all_data[sample_id]
        print(f"  ID: {sample_id}")
        print(f"  Source: {sample_doc.get('_source')}")
        print(f"  Keys: {list(sample_doc.keys())[:5]}...")
