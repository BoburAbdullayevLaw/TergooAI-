"""
API Models
==========
Pydantic models for FastAPI endpoints.

Author: TergooAI Team
Date: 2024
"""

from pydantic import BaseModel, Field
from typing import List, Optional, Dict, Any
from datetime import datetime


# ============================================================================
# REQUEST MODELS
# ============================================================================

class SearchRequest(BaseModel):
    """Search request model."""
    query: str = Field(..., description="Search query", min_length=1)
    top_k: Optional[int] = Field(5, description="Number of results", ge=1, le=20)
    threshold: Optional[float] = Field(0.6, description="Similarity threshold", ge=0.0, le=1.0)
    include_full_data: Optional[bool] = Field(False, description="Include full document data")
    source_filter: Optional[str] = Field(None, description="Filter by source: JK, JPK, KRIM")
    
    class Config:
        json_schema_extra = {
            "example": {
                "query": "JK 97-2(a) nima?",
                "top_k": 5,
                "threshold": 0.6,
                "source_filter": "JK"
            }
        }


class BatchSearchRequest(BaseModel):
    """Batch search request model."""
    queries: List[str] = Field(..., description="List of queries", min_length=1, max_length=50)
    top_k: Optional[int] = Field(5, description="Number of results per query")
    threshold: Optional[float] = Field(0.6, description="Similarity threshold")
    
    class Config:
        json_schema_extra = {
            "example": {
                "queries": [
                    "JK 97-2(a) nima?",
                    "Ikki odamni o'ldirish",
                    "Og'irlashtiruvchi holatlar"
                ],
                "top_k": 3
            }
        }


# ============================================================================
# RESPONSE MODELS
# ============================================================================

class SearchResultItem(BaseModel):
    """Single search result."""
    id: str = Field(..., description="Document ID")
    score: float = Field(..., description="Similarity score", ge=0.0, le=1.0)
    rank: int = Field(..., description="Result rank", ge=1)
    source: Optional[str] = Field(None, description="Source: JK, JPK, KRIM")
    modda_raqam: Optional[str] = Field(None, description="Modda raqami")
    emoji_sarlavha: Optional[str] = Field(None, description="Emoji sarlavha")
    asosiy_matn: Optional[str] = Field(None, description="Asosiy matn")
    full_data: Optional[Dict[str, Any]] = Field(None, description="Full document data")


class SearchResponse(BaseModel):
    """Search response model."""
    query: str = Field(..., description="Original query")
    results: List[SearchResultItem] = Field(..., description="Search results")
    total_found: int = Field(..., description="Total results found")
    search_time_ms: float = Field(..., description="Search time in milliseconds")
    timestamp: datetime = Field(default_factory=datetime.now, description="Response timestamp")
    
    class Config:
        json_schema_extra = {
            "example": {
                "query": "JK 97-2(a) nima?",
                "results": [
                    {
                        "id": "JK-097-SHARH-002",
                        "score": 0.92,
                        "rank": 1,
                        "source": "JK",
                        "modda_raqam": "97",
                        "emoji_sarlavha": "👥 Ikki+ odam",
                        "asosiy_matn": "JK 97-2(a): Ikki yoki undan ortiq shaxsni..."
                    }
                ],
                "total_found": 1,
                "search_time_ms": 45.2,
                "timestamp": "2024-01-15T10:30:00"
            }
        }


class BatchSearchResponse(BaseModel):
    """Batch search response model."""
    results: List[SearchResponse] = Field(..., description="List of search responses")
    total_queries: int = Field(..., description="Total queries processed")
    total_time_ms: float = Field(..., description="Total processing time")


class DocumentResponse(BaseModel):
    """Document detail response."""
    id: str
    source: str
    data: Dict[str, Any]


class StatsResponse(BaseModel):
    """Statistics response."""
    documents: Dict[str, int]
    database: Dict[str, Any]
    uptime_seconds: Optional[float] = None


class HealthResponse(BaseModel):
    """Health check response."""
    status: str = Field(..., description="Health status")
    version: str = Field(..., description="Application version")
    ml_system: str = Field(..., description="ML system status")
    database_size: int = Field(..., description="Database vector count")
    timestamp: datetime = Field(default_factory=datetime.now)


# ============================================================================
# ERROR MODELS
# ============================================================================

class ErrorResponse(BaseModel):
    """Error response model."""
    error: str = Field(..., description="Error type")
    message: str = Field(..., description="Error message")
    detail: Optional[str] = Field(None, description="Detailed error information")
    timestamp: datetime = Field(default_factory=datetime.now)
    
    class Config:
        json_schema_extra = {
            "example": {
                "error": "ValidationError",
                "message": "Invalid query parameter",
                "detail": "Query must be at least 1 character long",
                "timestamp": "2024-01-15T10:30:00"
            }
        }


# ============================================================================
# UTILITY MODELS
# ============================================================================

class PingResponse(BaseModel):
    """Ping response."""
    message: str = "pong"
    timestamp: datetime = Field(default_factory=datetime.now)


class InfoResponse(BaseModel):
    """Application info response."""
    name: str
    version: str
    environment: str
    description: str
